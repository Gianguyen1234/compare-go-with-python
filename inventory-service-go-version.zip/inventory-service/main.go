package main

import (
	"context"
	"encoding/json"
	"log"
	"net/http"
	"os"
	"time"

	"github.com/gorilla/mux"
	"github.com/jackc/pgx/v5/pgxpool"
	"github.com/joho/godotenv"
)

type Inventory struct {
	ProductID string `json:"product_id"`
	Quantity  int    `json:"quantity"`
}

var db *pgxpool.Pool

func connectDB() {
	err := godotenv.Load()
	if err != nil {
		log.Fatal("Error loading .env")
	}

	dbURL := os.Getenv("DATABASE_URL")
	pool, err := pgxpool.New(context.Background(), dbURL)
	if err != nil {
		log.Fatal("❌ Cannot connect to DB:", err)
	}
	db = pool
	log.Println("✅ Connected to PostgreSQL")
}

func getInventory(w http.ResponseWriter, r *http.Request) {
	vars := mux.Vars(r)
	productID := vars["product_id"]

	var quantity int
	err := db.QueryRow(context.Background(),
		`SELECT quantity FROM inventories WHERE product_id = $1`, productID).Scan(&quantity)

	if err != nil {
		http.Error(w, "Product not found", http.StatusNotFound)
		return
	}

	resp := map[string]any{"available": quantity > 0, "quantity": quantity}
	json.NewEncoder(w).Encode(resp)
}

func createInventory(w http.ResponseWriter, r *http.Request) {
	var inv Inventory
	json.NewDecoder(r.Body).Decode(&inv)

	_, err := db.Exec(context.Background(),
		`INSERT INTO inventories (product_id, quantity, updated_at) VALUES ($1, $2, $3)`,
		inv.ProductID, inv.Quantity, time.Now())

	if err != nil {
		http.Error(w, "Insert failed", http.StatusBadRequest)
		return
	}

	w.WriteHeader(http.StatusCreated)
}

func updateInventory(w http.ResponseWriter, r *http.Request) {
	vars := mux.Vars(r)
	productID := vars["product_id"]

	var inv Inventory
	json.NewDecoder(r.Body).Decode(&inv)

	_, err := db.Exec(context.Background(),
		`UPDATE inventories SET quantity = $1, updated_at = $2 WHERE product_id = $3`,
		inv.Quantity, time.Now(), productID)

	if err != nil {
		http.Error(w, "Update failed", http.StatusBadRequest)
		return
	}
}

func main() {

	start := time.Now()
	connectDB()

	r := mux.NewRouter()
	r.Use(corsMiddleware) // ✅ Middleware CORS chạy trước mọi route

	r.HandleFunc("/inventory/{product_id}", getInventory).Methods("GET")
	r.HandleFunc("/inventory/{product_id}", updateInventory).Methods("PUT")
	r.HandleFunc("/inventory", createInventory).Methods("POST")

	r.NotFoundHandler = http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		enableCORS(w)
		http.Error(w, "404 Not Found", http.StatusNotFound)
	})

	// When ready:
	elapsed := time.Since(start)
	log.Printf("🚀 Startup complete in %s\n", elapsed)

	log.Println("📦 inventory-service running on :8086")
	log.Fatal(http.ListenAndServe(":8086", r))
}
